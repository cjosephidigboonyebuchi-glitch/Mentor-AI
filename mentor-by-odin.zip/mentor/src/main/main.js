const { app, BrowserWindow, ipcMain, screen, globalShortcut, Tray, Menu, nativeImage, systemPreferences } = require('electron');
const path = require('path');

let overlayWindow = null;
let panelWindow = null;
let tray = null;
let cursorTrackingInterval = null;
let isOverlayVisible = true;

// ─── Overlay (floating dot that follows cursor) ───────────────────────────────
function createOverlayWindow() {
  overlayWindow = new BrowserWindow({
    width: 56,
    height: 56,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    focusable: false,
    hasShadow: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  overlayWindow.loadFile(path.join(__dirname, '../renderer/overlay.html'));
  overlayWindow.setIgnoreMouseEvents(false);

  // Make window click-through EXCEPT for the actual dot
  overlayWindow.on('ready-to-show', () => {
    overlayWindow.show();
    startCursorTracking();
  });
}

// ─── Panel (AI response window) ──────────────────────────────────────────────
function createPanelWindow() {
  panelWindow = new BrowserWindow({
    width: 420,
    height: 580,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: true,
    show: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  panelWindow.loadFile(path.join(__dirname, '../renderer/panel.html'));
}

// ─── Cursor tracking ─────────────────────────────────────────────────────────
function startCursorTracking() {
  cursorTrackingInterval = setInterval(() => {
    if (!overlayWindow || overlayWindow.isDestroyed()) return;
    const point = screen.getCursorScreenPoint();
    const display = screen.getDisplayNearestPoint(point);
    const { bounds } = display;

    // Offset so dot appears near but not ON the cursor (top-right)
    const offsetX = 18;
    const offsetY = -20;

    let x = point.x + offsetX;
    let y = point.y + offsetY;

    // Keep within screen bounds
    x = Math.max(bounds.x, Math.min(x, bounds.x + bounds.width - 56));
    y = Math.max(bounds.y, Math.min(y, bounds.y + bounds.height - 56));

    overlayWindow.setPosition(Math.round(x), Math.round(y), false);
  }, 16); // ~60fps
}

// ─── Screen capture + OCR ────────────────────────────────────────────────────
async function captureScreenContext(cursorX, cursorY) {
  try {
    // We'll capture via renderer's desktopCapturer
    return { x: cursorX, y: cursorY };
  } catch (err) {
    console.error('Capture error:', err);
    return null;
  }
}

// ─── Position panel near cursor ───────────────────────────────────────────────
function positionPanel(cursorX, cursorY) {
  const display = screen.getDisplayNearestPoint({ x: cursorX, y: cursorY });
  const { bounds } = display;
  const panelW = 420;
  const panelH = 580;

  let x = cursorX + 30;
  let y = cursorY - 100;

  // Flip left if too close to right edge
  if (x + panelW > bounds.x + bounds.width - 20) {
    x = cursorX - panelW - 30;
  }
  // Clamp vertical
  if (y + panelH > bounds.y + bounds.height - 20) {
    y = bounds.y + bounds.height - panelH - 20;
  }
  y = Math.max(bounds.y + 20, y);

  panelWindow.setPosition(Math.round(x), Math.round(y));
}

// ─── IPC handlers ─────────────────────────────────────────────────────────────
ipcMain.handle('get-cursor-pos', () => screen.getCursorScreenPoint());

ipcMain.on('overlay-clicked', async (event, { x, y }) => {
  if (!panelWindow || panelWindow.isDestroyed()) return;

  positionPanel(x, y);
  panelWindow.show();
  panelWindow.focus();
  panelWindow.webContents.send('capture-requested', { x, y });
});

ipcMain.on('close-panel', () => {
  if (panelWindow && !panelWindow.isDestroyed()) {
    panelWindow.hide();
  }
});

ipcMain.on('toggle-overlay', () => {
  if (!overlayWindow || overlayWindow.isDestroyed()) return;
  isOverlayVisible = !isOverlayVisible;
  if (isOverlayVisible) {
    overlayWindow.show();
  } else {
    overlayWindow.hide();
    if (panelWindow && !panelWindow.isDestroyed()) panelWindow.hide();
  }
});

ipcMain.on('panel-drag', (event, { deltaX, deltaY }) => {
  if (!panelWindow || panelWindow.isDestroyed()) return;
  const [x, y] = panelWindow.getPosition();
  panelWindow.setPosition(x + deltaX, y + deltaY);
});

// ─── Tray ─────────────────────────────────────────────────────────────────────
function createTray() {
  // Create a simple tray icon programmatically
  const iconSize = 16;
  const { nativeImage } = require('electron');
  
  // Use a simple colored icon
  tray = new Tray(nativeImage.createEmpty());
  
  const contextMenu = Menu.buildFromTemplate([
    { label: 'Mentor by Odin', enabled: false },
    { type: 'separator' },
    {
      label: 'Toggle Mentor',
      accelerator: 'Alt+M',
      click: () => {
        if (overlayWindow) overlayWindow.webContents.send('toggle-request');
      }
    },
    { type: 'separator' },
    {
      label: 'Settings',
      click: () => {
        if (panelWindow) {
          panelWindow.webContents.send('show-settings');
          panelWindow.show();
        }
      }
    },
    { type: 'separator' },
    { label: 'Quit Mentor', click: () => app.quit() },
  ]);

  tray.setToolTip('Mentor by Odin');
  tray.setContextMenu(contextMenu);
}

// ─── App lifecycle ─────────────────────────────────────────────────────────────
app.whenReady().then(() => {
  createOverlayWindow();
  createPanelWindow();
  createTray();

  // Global shortcut to toggle
  globalShortcut.register('Alt+M', () => {
    isOverlayVisible = !isOverlayVisible;
    if (isOverlayVisible) {
      overlayWindow.show();
    } else {
      overlayWindow.hide();
      panelWindow.hide();
    }
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createOverlayWindow();
      createPanelWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  if (cursorTrackingInterval) clearInterval(cursorTrackingInterval);
});

// Prevent app from showing in dock (macOS)
if (app.dock) app.dock.hide();
