# Mentor by Odin

> Your AI screen advisor — always watching, always ready.

## What it does

Mentor is a desktop overlay app that follows your cursor. Click the glowing dot to get instant AI-powered explanations and advice about anything on your screen — text, UI, documents, data, code, or any interface.

## Quick Start

### Prerequisites
- Node.js 18+
- An Anthropic API key → https://console.anthropic.com

### Install & Run

```bash
npm install
npm start
```

### Build distributable

```bash
npm run build
# Output in /dist
```

## How to use

1. Launch the app — a glowing **M dot** appears near your cursor
2. Move your cursor to anything on screen you want help with
3. **Click the dot** → Mentor captures your screen and explains what you're seeing
4. Type follow-up questions in the panel
5. Press `Alt+M` to toggle Mentor on/off
6. Click ⚙️ to set your Anthropic API key

## Architecture

```
mentor/
├── src/
│   ├── main/
│   │   ├── main.js          # Electron main process
│   │   │                    # Window management, cursor tracking, IPC
│   │   └── preload.js       # IPC bridge (contextIsolation)
│   └── renderer/
│       ├── overlay.html     # Floating dot that follows cursor
│       └── panel.html       # AI advisor panel (capture + response)
├── package.json
└── README.md
```

## Key technical details

- **Cursor tracking**: `setInterval` at 16ms polling `screen.getCursorScreenPoint()`
- **Screen capture**: Electron `desktopCapturer` API
- **OCR**: `tesseract.js` for text extraction from screenshots
- **AI**: `@anthropic-ai/sdk` → `claude-sonnet-4-6`
- **Always-on-top**: `alwaysOnTop: true` + `skipTaskbar: true`
- **Transparent overlay**: `transparent: true` + `frame: false`
- **Tray icon** + global shortcut `Alt+M`

## Permissions needed (macOS)

- Screen Recording (for `desktopCapturer`)
- Accessibility (for overlay positioning)

System Preferences → Privacy & Security → Screen Recording → add Mentor

## Built by Odin
