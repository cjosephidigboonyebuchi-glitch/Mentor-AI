#!/bin/bash
echo ""
echo "  ╔═══════════════════════════════╗"
echo "  ║     MENTOR  by  ODIN          ║"
echo "  ║     Your AI Screen Advisor    ║"
echo "  ╚═══════════════════════════════╝"
echo ""

# Check Node
if ! command -v node &> /dev/null; then
  echo "  ✗ Node.js not found. Install from https://nodejs.org"
  exit 1
fi

NODE_VER=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VER" -lt 18 ]; then
  echo "  ✗ Node.js 18+ required (you have $(node -v))"
  exit 1
fi

echo "  ✓ Node.js $(node -v) detected"
echo ""
echo "  Installing dependencies..."
npm install

echo ""
echo "  ✓ Done! Launch Mentor with:"
echo ""
echo "      npm start"
echo ""
echo "  Then set your Anthropic API key in the ⚙️ settings panel."
echo ""
