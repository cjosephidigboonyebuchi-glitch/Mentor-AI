import Fastify from "fastify";
import cors from "@fastify/cors";
import jwt from "@fastify/jwt";
import rateLimit from "@fastify/rate-limit";
import websocket from "@fastify/websocket";

import { redis } from "./db/redis.js";
import authenticatePlugin from "./plugins/authenticate.js";
import authRoutes from "./routes/auth.js";
import sessionRoutes from "./routes/session.js";

const app = Fastify({ logger: true });

// --- API Gateway concerns: CORS, rate limiting, JWT verification ---
await app.register(cors, { origin: true }); // tighten to your desktop app's origin in production
await app.register(jwt, { secret: process.env.JWT_ACCESS_SECRET });
await app.register(websocket);
await app.register(rateLimit, {
  max: Number(process.env.RATE_LIMIT_MAX ?? 60),
  timeWindow: Number(process.env.RATE_LIMIT_WINDOW_SEC ?? 60) * 1000,
  redis,
  keyGenerator: (req) => req.user?.sub ?? req.ip, // per-user once authenticated, per-IP before login
});

await app.register(authenticatePlugin);

// --- Routes ---
await app.register(authRoutes);
await app.register(sessionRoutes);

app.get("/health", async () => ({ status: "ok", time: new Date().toISOString() }));

const port = Number(process.env.PORT ?? 3000);
app.listen({ port, host: "0.0.0.0" }).catch((err) => {
  app.log.error(err);
  process.exit(1);
});
