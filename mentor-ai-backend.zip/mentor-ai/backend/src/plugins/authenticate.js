import fp from "fastify-plugin";

/**
 * Adds app.authenticate, used as an onRequest hook on any protected route.
 * Mirrors the API Gateway's "verify JWT before routing anywhere" rule from
 * the MentorG1 architecture doc - no internal route is reachable without it.
 */
export default fp(async function authenticatePlugin(app) {
  app.decorate("authenticate", async (req, reply) => {
    try {
      await req.jwtVerify();
    } catch {
      reply.code(401).send({ error: "missing or invalid access token" });
    }
  });
});
