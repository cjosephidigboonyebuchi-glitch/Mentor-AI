-- Mentor AI schema
-- Applied automatically on first Postgres container start via docker-entrypoint-initdb.d

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email           TEXT UNIQUE NOT NULL,
    password_hash   TEXT NOT NULL,
    display_name    TEXT,
    subscription_tier TEXT NOT NULL DEFAULT 'free'
                        CHECK (subscription_tier IN ('free', 'tier_5', 'tier_10', 'tier_35')),
    daily_time_limit_minutes INTEGER, -- NULL = unlimited (tier_10 / tier_35)
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One row per logged-in client instance (desktop app on this machine, later: a pair of glasses)
CREATE TABLE IF NOT EXISTS devices (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_type     TEXT NOT NULL DEFAULT 'desktop' CHECK (device_type IN ('desktop', 'glasses')),
    device_label    TEXT, -- e.g. "Alex's MacBook", "MentorG1 #A19381"
    refresh_token_hash TEXT,
    last_seen_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Active session bookkeeping (mirrors the hot copy kept in Redis; this is the durable record)
CREATE TABLE IF NOT EXISTS sessions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_id       UUID REFERENCES devices(id) ON DELETE SET NULL,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    ended_at        TIMESTAMPTZ,
    seconds_active  INTEGER NOT NULL DEFAULT 0
);

-- Every AI call, logged for cost tracking / debugging / usage-tier enforcement
CREATE TABLE IF NOT EXISTS usage_logs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_id      UUID REFERENCES sessions(id) ON DELETE SET NULL,
    task_type       TEXT NOT NULL, -- 'reading_assist' | 'technical' | 'translation' | 'general'
    provider        TEXT NOT NULL, -- 'openai' | 'anthropic' | 'google_vertex'
    prompt_tokens   INTEGER,
    completion_tokens INTEGER,
    latency_ms      INTEGER,
    status          TEXT NOT NULL DEFAULT 'ok', -- 'ok' | 'error'
    error_message   TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_usage_logs_user_created ON usage_logs (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions (user_id);
CREATE INDEX IF NOT EXISTS idx_devices_user ON devices (user_id);
