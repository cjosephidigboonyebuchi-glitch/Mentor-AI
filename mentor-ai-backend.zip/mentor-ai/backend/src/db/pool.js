import pg from "pg";

const { Pool } = pg;

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20, // safe ceiling for 100 concurrent users on a single mini server
  idleTimeoutMillis: 30_000,
});

pool.on("error", (err) => {
  // A connection died in the pool - log but don't crash the process
  console.error("[postgres] unexpected error on idle client", err);
});
