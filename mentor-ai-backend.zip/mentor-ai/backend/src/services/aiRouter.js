import OpenAI from "openai";
import { pool } from "../db/pool.js";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/**
 * classifyTask - looks at CONTENT, not device.
 * The same classifier serves desktop (screen/reading content) and, later,
 * glasses (real-world scene content) - neither the caller nor this function
 * needs to know which device the frame came from.
 *
 * This is intentionally a simple keyword/heuristic classifier for the MVP.
 * Swap in a cheap small-model classification call here once you have real
 * usage data to tune it against.
 */
export function classifyTask({ text = "", hasImage = false }) {
  const lower = text.toLowerCase();

  const technicalSignals = ["fix", "wire", "error code", "broken", "install", "connect", "won't turn on", "circuit"];
  const translationSignals = ["translate", "what does this mean in", "how do i say"];
  const financialSignals = ["stock", "invest", "crypto", "price", "market", "buy", "sell", "coin"];

  if (translationSignals.some((s) => lower.includes(s))) return "translation";
  if (technicalSignals.some((s) => lower.includes(s)) && hasImage) return "technical";
  if (financialSignals.some((s) => lower.includes(s))) return "reading_assist";

  return "reading_assist"; // default for the desktop MVP - explanatory/intellectual assistance
}

/**
 * routeAndRespond - Provider selection + call + formatting, in one place.
 * MVP: OpenAI only, per the MentorG1 Phase-1 scope. Add Anthropic/Vertex
 * branches here in Phase 2 without touching any caller of this function.
 */
export async function routeAndRespond({ userId, sessionId, taskType, text, imageBase64 }) {
  const started = Date.now();
  const provider = "openai"; // only branch for MVP; task-based routing table goes here in Phase 2

  const systemPrompt = buildSystemPrompt(taskType);

  const userContent = [{ type: "text", text }];
  if (imageBase64) {
    userContent.push({
      type: "image_url",
      image_url: { url: `data:image/jpeg;base64,${imageBase64}` },
    });
  }

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent },
      ],
      max_tokens: 300,
    });

    const message = completion.choices[0]?.message?.content ?? "";
    const latencyMs = Date.now() - started;

    await logUsage({
      userId,
      sessionId,
      taskType,
      provider,
      promptTokens: completion.usage?.prompt_tokens,
      completionTokens: completion.usage?.completion_tokens,
      latencyMs,
      status: "ok",
    });

    return { taskType, provider, message, latencyMs };
  } catch (err) {
    await logUsage({
      userId,
      sessionId,
      taskType,
      provider,
      latencyMs: Date.now() - started,
      status: "error",
      errorMessage: err.message,
    });
    throw err;
  }
}

function buildSystemPrompt(taskType) {
  const persona =
    "You are Mentor AI: interactive, human, a little humorous, never robotic. " +
    "You notice what the user is stuck on and explain it simply, then suggest one concrete " +
    "way they could act on or benefit from the situation. Keep responses short - a few sentences, not an essay.";

  const taskHints = {
    reading_assist: "The user has re-read or lingered on something and needs it explained simply, with a practical angle.",
    technical: "The user is looking at a real-world technical problem (device, wiring, hardware). Give a clear, safe, step-by-step fix.",
    translation: "The user needs a quick, natural translation or explanation of unfamiliar language.",
  };

  return `${persona}\n\nContext: ${taskHints[taskType] ?? taskHints.reading_assist}`;
}

async function logUsage({ userId, sessionId, taskType, provider, promptTokens, completionTokens, latencyMs, status, errorMessage }) {
  await pool.query(
    `INSERT INTO usage_logs
      (user_id, session_id, task_type, provider, prompt_tokens, completion_tokens, latency_ms, status, error_message)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
    [userId, sessionId ?? null, taskType, provider, promptTokens ?? null, completionTokens ?? null, latencyMs, status, errorMessage ?? null]
  );
}
