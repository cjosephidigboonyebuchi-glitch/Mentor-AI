import { pool } from "../db/pool.js";
import { redis } from "../db/redis.js";
import { classifyTask, routeAndRespond } from "../services/aiRouter.js";

/**
 * POST /api/analyze - the "Aides-moi" trigger equivalent.
 * Client sends { text, imageBase64 } when it detects a stuck/re-read moment
 * (or when the user explicitly asks). Backend classifies, calls the AI
 * provider, logs usage, and returns the formatted response.
 *
 * A WebSocket channel (/ws) stays open per session for future streaming -
 * MVP returns the full response in the POST for simplicity; swap to
 * streamed WS chunks once token-by-token display is worth the complexity.
 */
export default async function sessionRoutes(app) {
  app.post(
    "/api/analyze",
    { onRequest: [app.authenticate] },
    async (req, reply) => {
      const { text, imageBase64, sessionId } = req.body ?? {};
      if (!text && !imageBase64) {
        return reply.code(400).send({ error: "text or imageBase64 required" });
      }

      const userId = req.user.sub;

      // Enforce free-tier daily time limit (2h/day) via Redis counter.
      const tier = req.user.tier;
      if (tier === "tier_5") {
        const usedSeconds = Number((await redis.get(`usage:${userId}:${todayKey()}`)) ?? 0);
        if (usedSeconds > 2 * 60 * 60) {
          return reply.code(402).send({ error: "daily time limit reached for your plan - upgrade for unlimited time" });
        }
      }

      const taskType = classifyTask({ text, hasImage: Boolean(imageBase64) });

      try {
        const result = await routeAndRespond({
          userId,
          sessionId,
          taskType,
          text: text ?? "",
          imageBase64,
        });
        return reply.send(result);
      } catch (err) {
        req.log.error(err);
        return reply.code(502).send({ error: "the AI provider failed to respond - please try again" });
      }
    }
  );

  app.post("/api/session/start", { onRequest: [app.authenticate] }, async (req, reply) => {
    const userId = req.user.sub;
    const deviceId = req.user.deviceId ?? null;
    const result = await pool.query(
      `INSERT INTO sessions (user_id, device_id) VALUES ($1, $2) RETURNING id, started_at`,
      [userId, deviceId]
    );
    return reply.send(result.rows[0]);
  });

  app.post("/api/session/:id/end", { onRequest: [app.authenticate] }, async (req, reply) => {
    const { id } = req.params;
    const { secondsActive } = req.body ?? {};
    await pool.query(
      `UPDATE sessions SET ended_at = now(), seconds_active = $2 WHERE id = $1 AND user_id = $3`,
      [id, secondsActive ?? 0, req.user.sub]
    );
    if (secondsActive) {
      await redis.incrby(`usage:${req.user.sub}:${todayKey()}`, secondsActive);
      await redis.expire(`usage:${req.user.sub}:${todayKey()}`, 60 * 60 * 26); // slightly over a day
    }
    return reply.send({ ok: true });
  });

  app.get("/ws", { websocket: true, onRequest: [app.authenticate] }, (connection, req) => {
    connection.socket.on("message", (raw) => {
      // Reserved for Phase 2 token-by-token streaming; MVP just echoes a heartbeat.
      connection.socket.send(JSON.stringify({ type: "ack", receivedAt: Date.now() }));
    });
  });
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}
