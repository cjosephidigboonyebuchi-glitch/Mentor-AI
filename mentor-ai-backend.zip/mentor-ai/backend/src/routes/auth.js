import argon2 from "argon2";
import { randomUUID } from "node:crypto";
import { pool } from "../db/pool.js";

/**
 * Auth & User Service (Layer 3 equivalent from the MentorG1 architecture doc).
 * Issues short-lived access tokens (15 min) + long-lived refresh tokens (30 days),
 * same split TechnoWise's doc specified for the hardware version.
 */
export default async function authRoutes(app) {
  app.post("/api/auth/register", async (req, reply) => {
    const { email, password, displayName } = req.body ?? {};
    if (!email || !password || password.length < 8) {
      return reply.code(400).send({ error: "email and password (8+ chars) are required" });
    }

    const existing = await pool.query("SELECT id FROM users WHERE email = $1", [email]);
    if (existing.rowCount > 0) {
      return reply.code(409).send({ error: "an account with this email already exists" });
    }

    const passwordHash = await argon2.hash(password);
    const result = await pool.query(
      `INSERT INTO users (email, password_hash, display_name)
       VALUES ($1, $2, $3)
       RETURNING id, email, display_name, subscription_tier`,
      [email, passwordHash, displayName ?? null]
    );

    const user = result.rows[0];
    const tokens = await issueTokens(app, user);
    return reply.code(201).send({ user, ...tokens });
  });

  app.post("/api/auth/login", async (req, reply) => {
    const { email, password, deviceLabel, deviceType } = req.body ?? {};
    if (!email || !password) {
      return reply.code(400).send({ error: "email and password are required" });
    }

    const result = await pool.query(
      "SELECT id, email, password_hash, display_name, subscription_tier FROM users WHERE email = $1",
      [email]
    );
    const user = result.rows[0];
    if (!user || !(await argon2.verify(user.password_hash, password))) {
      return reply.code(401).send({ error: "invalid email or password" });
    }

    const device = await pool.query(
      `INSERT INTO devices (user_id, device_type, device_label, last_seen_at)
       VALUES ($1, $2, $3, now())
       RETURNING id`,
      [user.id, deviceType ?? "desktop", deviceLabel ?? null]
    );

    delete user.password_hash;
    const tokens = await issueTokens(app, user, device.rows[0].id);
    return reply.send({ user, deviceId: device.rows[0].id, ...tokens });
  });

  app.post("/api/auth/refresh", async (req, reply) => {
    const { refreshToken } = req.body ?? {};
    if (!refreshToken) return reply.code(400).send({ error: "refreshToken required" });

    try {
      const payload = app.jwt.verify(refreshToken, { key: process.env.JWT_REFRESH_SECRET });
      const accessToken = app.jwt.sign(
        { sub: payload.sub, tier: payload.tier },
        { expiresIn: "15m" }
      );
      return reply.send({ accessToken });
    } catch {
      return reply.code(401).send({ error: "invalid or expired refresh token" });
    }
  });
}

async function issueTokens(app, user, deviceId) {
  const accessToken = app.jwt.sign(
    { sub: user.id, tier: user.subscription_tier, deviceId },
    { expiresIn: "15m" }
  );
  const refreshToken = app.jwt.sign(
    { sub: user.id, tier: user.subscription_tier, jti: randomUUID() },
    { key: process.env.JWT_REFRESH_SECRET, expiresIn: "30d" }
  );
  return { accessToken, refreshToken };
}
