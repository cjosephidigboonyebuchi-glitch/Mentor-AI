# Mentor AI - Backend MVP

This is the backend for Mentor AI: the AI Router / Auth / DB stack described in the
MentorG1 architecture doc, adapted to be device-agnostic (desktop today, glasses later).
It follows the same four-layer split - only Layer 1 (glasses vs. webcam/mic) and
Layer 2 (companion app vs. desktop app) change between hardware and software mode.

## What's in this repo

```
mentor-ai/
├── docker-compose.yml     # orchestrates postgres, redis, backend, caddy
├── Caddyfile              # reverse proxy + automatic HTTPS
├── .env.example           # copy to .env and fill in real secrets
├── backend/
│   ├── src/
│   │   ├── server.js              # API Gateway: CORS, rate limit, JWT, route registration
│   │   ├── routes/auth.js         # register / login / refresh
│   │   ├── routes/session.js      # /api/analyze (the core loop), session start/end, /ws
│   │   ├── services/aiRouter.js   # task classifier + OpenAI call + usage logging
│   │   ├── plugins/authenticate.js
│   │   └── db/schema.sql          # users, devices, sessions, usage_logs
└── client/index.html      # bare-bones browser harness to test the full loop
```

## What is NOT included (by design, matching the MentorG1 MVP scope)

- Multi-provider routing (Anthropic/Vertex) - stub is in `aiRouter.js`, wire in Phase 2
- The real desktop app UI (Electron/Tauri shell, always-on tray icon, hotkey trigger) -
  `client/index.html` proves the loop; the engineer should treat the real client as a
  separate build
- Payment/subscription enforcement beyond the free-tier time cap - Stripe webhook
  → `subscription_tier` update is a Phase 2 task
- Redis-backed response caching, analytics dashboard, OTA config

## Local setup (for your engineer, before touching the server)

1. Install Docker + Docker Compose.
2. `cp .env.example .env` and fill in:
   - `POSTGRES_PASSWORD`, `REDIS_PASSWORD` — any strong random strings
   - `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET` — generate with `openssl rand -hex 32`
   - `OPENAI_API_KEY` — from platform.openai.com, with a billing limit set
   - `MENTOR_DOMAIN` — leave as `localhost` for local testing
3. `docker compose up --build`
4. Open `client/index.html` directly in a browser (or serve it with any static server),
   point "Backend URL" at `http://localhost:3000`, log in, enable camera, trigger analysis.
5. Check `/health` returns `{"status":"ok"}`.

## Hosting on your own hardware ("mini data center") for 100+ users

This is the part that differs from a cloud deploy. A local machine can absolutely handle
this - the workload is mostly waiting on OpenAI, not local compute - but a few things
need to be right before you point real users at it.

### 1. Networking
- **Static IP or dynamic DNS.** Your ISP likely gives you a dynamic IP. Use a service
  like DuckDNS, No-IP, or Cloudflare's dynamic DNS to give your box a stable hostname
  (this is `MENTOR_DOMAIN` in `.env`).
- **Port forwarding.** Forward ports 80 and 443 on your router to the mini's local IP.
  Do NOT forward 5432 (Postgres) or 6379 (Redis) - the compose file already binds
  those to `127.0.0.1` only, so they're unreachable from outside even if you forget.
- **Firewall.** Only 80/443 should be open to the internet on the machine itself
  (`ufw allow 80,443/tcp` on Linux, or your OS's equivalent).

### 2. TLS
Caddy (already in `docker-compose.yml`) auto-provisions and renews a Let's Encrypt
certificate for `MENTOR_DOMAIN` the first time it starts, as long as DNS is pointed
at your IP and port 80 is reachable for the ACME challenge. No manual cert management
needed.

### 3. Capacity check for ~100 concurrent users
- Postgres pool is capped at 20 connections (`backend/src/db/pool.js`) - fine for 100
  users making occasional requests, not fine if you expect sustained heavy concurrency;
  raise it if `pool exhausted` errors show up in logs.
- Rate limiting (`RATE_LIMIT_MAX`/`RATE_LIMIT_WINDOW_SEC` in `.env`) protects both your
  OpenAI bill and the box from a runaway client. Tune per your pricing tiers.
- The real bottleneck at this scale is usually **upload bandwidth** (100 users sending
  camera frames) more than CPU. Check your connection's upload speed before launch;
  if it's under ~20 Mbps upload, expect lag under load and consider compressing frames
  more aggressively client-side (the test client already downscales to JPEG quality 0.7).

### 4. Reliability basics before charging money
- **Backups:** `docker exec` a nightly `pg_dump` of the `postgres` volume to an
  external drive or cloud bucket - losing the users table is not recoverable otherwise.
- **Restart policy:** already set to `unless-stopped` in compose, so a power blip
  recovers on its own once the machine reboots.
- **Monitoring:** at minimum, put a free uptime checker (UptimeRobot, Better Stack)
  on `https://MENTOR_DOMAIN/health` so you find out about downtime before users do.
- **Power/internet redundancy:** worth a UPS for the mini if you're hosting production
  traffic on home/office power and internet - a single outage takes down every user.

### 5. Scaling beyond this box later
Nothing above needs to change for the glasses integration - a new device_type
('glasses') already exists in the schema, and the AI Router doesn't care which
Layer 1 client sent the request. When you outgrow the mini, the same `docker-compose.yml`
services map directly onto a cloud VM (AWS/GCP/Railway) with no code changes - only
the hosting layer moves.

## Handing this to your engineer

The engineer's first tasks, in order:
1. Get `docker compose up` running locally, confirm `/health` and the test client work.
2. Build the real desktop client (Electron or Tauri) replacing `client/index.html`:
   background camera/mic capture, the "re-read 3x" or hotkey trigger, an overlay UI
   for responses, and calling `/api/session/start` → `/api/analyze` → `/api/session/:id/end`.
3. Add Stripe (or similar) for subscription tier management, wiring webhook events to
   `UPDATE users SET subscription_tier = ...`.
4. Deploy to the mini data center following the hosting section above.
